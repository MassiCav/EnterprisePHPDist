# PHP Inotify

Inotify bindings for PHP 5 and PHP 7

This extension exposes the inotify API and some additional functions.

## Install

* PHP 5: pecl install inotify-0.1.6
* PHP 7: pecl install inotify

## Documentation

Documentation is available at https://php.net/inotify

